	//add more
	var index = 2;
	
	$('#but_add').click(function () {
		newDiv = document.createElement('div');
		newDiv.setAttribute('class', 'col-md-3');
		
		newLabel = document.createElement('label');
		newLabel.setAttribute('class', 'form-label');
		newLabel.setAttribute('id', 'friend_label'+index);
		newLabel.setAttribute('for', 'friend_name'+index);
		
		var inputName = document.createElement('input');
		inputName.setAttribute('type', 'text');
		inputName.setAttribute('class', 'form-control');
		inputName.setAttribute('name', 'fried_name' + index);
		inputName.setAttribute('id', 'friend_name' + index);
		inputName.setAttribute('maxlength', 20);
		
		newSpan = document.createElement('span');
		newSpan.setAttribute('class', 'error');
		newSpan.setAttribute('id', 'friend_name'+index+'_err');
		
		newDiv.append(newLabel);
		newDiv.append(inputName);
		newDiv.append(newSpan);
		$('#friend_list').append(newDiv);
		
		$('#friend_label'+index).html('Name:');
		$('#friend_name'+index).bind('keyup', function(event) {
			this.value = this.value.replace(/[^a-z]/g, '');
		});
		
		index++;
    });
	
	//function to display names
	$('#but_show').click(function () {
		var selected = [];
		var names = $('[id^="friend_name"]');
		for(var index = 0; index < names.length; index++){ 
			if(names[index].type == 'text' && names[index].value != '') {
				selected.push(names[index].value);
			}
		}
		$('#list_names').html('Friend names: '+ selected.join(', '));
	});